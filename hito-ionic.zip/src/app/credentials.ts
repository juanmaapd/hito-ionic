export var firebaseConfig = {
    apiKey: "AIzaSyCSzr6-AIUdfUcjL082rhDoqEsnSiZcHwc",
    authDomain: "juanma-hito03.firebaseapp.com",
    databaseURL: "https://juanma-hito03.firebaseio.com",
    projectId: "juanma-hito03",
    storageBucket: "juanma-hito03.appspot.com",
    messagingSenderId: "57340252122",
    appId: "1:57340252122:web:423781de858b4a12327ae3"
  };