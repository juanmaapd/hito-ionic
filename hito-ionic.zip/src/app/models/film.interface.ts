export interface Film {
    date: any;
    id: string;
    filmName: string;
    filmDescription: string;
    
}